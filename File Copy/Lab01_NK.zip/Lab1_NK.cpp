/*
Lab 1: File Copy
Author: Noah Khan
Description: Contents of one file is copied to another.
#######################################################

Pseudocode:
    Ask user for path of file to be read
    Store user input into string variable
    Open read file
    Dislpay success message if properly opened
    Ask user for path of file to be written
    Stores user input into a string variable
    Open write file
    While loop to iterate through read file
    Get lines from infile and store into variable named "contents"
    Store "contents" into outfile
    Close infile
    Close outfile
    System pause waits for user to close program
*/

#include <iostream>
#include <fstream>
#include <ios>
#include <iomanip>
#include <cstdlib>

using namespace std;

int main()
{
    ifstream  infile;                                               // Declare variables and other items
    ofstream outfile;
    string readFile, writeFile, contents;

    cout << "Enter the path of a file to be read: " << endl;        // Prompt user for read file path
    getline(cin, readFile);                                         // Store input

   infile.open(readFile.c_str());                                   // Open read file
   if (!infile)
   {
       cout << "Error. . .";                                        // Error message
   }
   else
   {
       cout << "Successfully opened!\n" << endl;                    // Success message
   }

    cout << "Enter the path of a file to be written: " << endl;     // Prompt user for write file path
    getline(cin, writeFile);                                        // Store input


    outfile.open(writeFile.c_str(), ios::app | ios::ate);           // Open with append and pointer flags

    while (infile)                                                  // While loop to get multiple lines of text
    {
        getline(infile, contents);                                  // Move information in read file to container
        outfile << contents + "\n";                                 // Move information from container to write file
    }                                                               // breakline to seperate lines of text


    infile.close();                                                 // Close files
    outfile.close();

    system("pause");                                                // Pause


    return 0;
}

