/*
Lab 2: Output Reverse File
Author: Noah Khan
Description: Contents of read file is displayed and copied
             to write file in reverse.
#######################################################

Pseudocode:
    Initialize items
    Loop that asks for read file path
    If file did not open, display error and ask for path again
    If file opens display success message
    Ask for write file path
    Create counter for while loop
    Copy read file contents to array, word-by-word
    Break Line
    Initialize counter named "num" for while loop
    Create for loop to iterate through array backwards
    If no string is found, continue loop
    If string found display string stored in array at index "num"
    Copy array content to write file
    Once for loop is complete, close read and write file
    System pause
*/

#include <iostream>
#include <fstream>
#include <ios>
#include <iomanip>
#include <cstdlib>
#include <vector>

using namespace std;

int main()
{
    ifstream  infile;                                               // Declare variables and other items
    ofstream outfile;
    string readFile, writeFile;
    int cnt = 1024;
    string words[cnt];


    do{                                                             // loop to ask for read file
        cout << "Enter path for read file: " << endl;
        getline(cin, readFile);                                     // get user input
        infile.open(readFile.c_str());                              // open

        if (!infile)                                                // if not open
        {
            cout << "Error. . ." << endl;                           // show error msg and loop again
        }
        else
        {
            cout << "Successfully opened file" << endl;             // if open, show good msg
        }

    }
    while(!infile);

    cout << '\n' << "Enter path for write file:" << endl;               // path for write file
    getline(cin, writeFile);
    outfile.open(writeFile.c_str());                                    // open file

    int num = 0;                                                        // transfer read file to array
    while(infile >> words[num])
    {
        num++;
    }


    cout << endl;                                                       // break line
    for (int i = cnt - 1; i > -1; i--)                                  // iterates through array backwards
    {
        if(words[i] == "")                                              // if empty, continue loop
        {
            continue;
        }
        else                                                            // if string
        {
        cout    << words[i] << endl;                                    // print
        outfile << words[i] << endl;                                    // store into write file
        }
    }

    infile.close();                                                     // close read file
    outfile.close();                                                    // close write file

    system("pause");                                                    // sys pause

    return 0;
}


//C:\\Users\\Khan\\Documents\\Coding Languages\\Intermediate C++\\Labs\\Lab 2\\Lab02_NK\\test1.txt
