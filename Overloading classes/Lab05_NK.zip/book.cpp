#include "book.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <string>


Book::Book()        // Default Constructor
{
    std::cout << "Book object being created by default constructor. . ." << std::endl;

    title = "--";
    author = "--";
    publisher = "--";
    dateAdded = "0/0/00";
    ISBN = "0";
    qtyInHand = "0";
    wholesaleCost = "0";
    retailPrice = "0";

    std::cout << "Book '" << getTitle() << "' by " << author << " has been created!" << std::endl;
}

Book::~Book()       // Destructor
{
    std::cout << "Book '" << getTitle() << "' by " << author <<
                  " destroyed successfully. . ." << std::endl;
}

Book::Book(std::string t, std::string a, std::string p, std::string da, std::string isbn, std::string qty, std::string wc, std::string rp) :
    title(t), author(a), publisher(p), dateAdded(da), ISBN(isbn), qtyInHand(qty), wholesaleCost(wc), retailPrice(rp)
{
    std::cout << std::endl;

    std::cout << "Book object being created by all parameter constructor. . ." << std::endl;

    std::cout << "Book '" << getTitle() << "' by " << author << " has been created!" << std::endl;
    std::cout << std::endl;
}


// Copy constructor
Book::Book(const Book& originalBookObj)
{
    std::cout << "Copying constructor called. . ." << std::endl;
    std::cout << "Copying Title Information. . ." << std::endl;
    this->title = originalBookObj.title;
    std::cout << "Copying Author Information. . ." << std::endl;
    author = originalBookObj.author;
    std::cout << "Copying Publisher Information. . ." << std::endl;
    publisher = originalBookObj.publisher;
    std::cout << "Copying Date Information. . ." << std::endl;
    dateAdded = originalBookObj.dateAdded;
    std::cout << "Copying ISBN Number. . ." << std::endl;
    ISBN = originalBookObj.ISBN;
    std::cout << "Copying Quantity in Hand. . ." << std::endl;
    qtyInHand = originalBookObj.qtyInHand;
    std::cout << "Copying Wholesale Cost Information. . ." << std::endl;
    wholesaleCost = originalBookObj.wholesaleCost;
    std::cout << "Copying Retail Price Information. . ." << std::endl;
    retailPrice = originalBookObj.retailPrice;
    std::cout << "Book '" << getTitle() << "' by " << getAuthor() << " has been successfully copied!" << std::endl;
    std::cout << std::endl;
}

//
bool Book::operator==(const Book& book1)
{
    std::cout << std::endl;
    std::cout << "Comparing '" << this->title << "' & '" << book1.title << "'. . ." << std::endl;

    return (this->title == book1.title &&
            this->author == book1.author &&
            this->publisher == book1.publisher &&
            this->dateAdded == book1.dateAdded &&
            this->ISBN == book1.ISBN);

}

// Overload output stream operator
std::ostream& operator<<(std::ostream& out, Book& toPrint)
{
    std::cout << std::endl;
    std::cout << "Using overloaded output operator. . ." << std::endl;

    out << "Book title: '" << toPrint.title << "'" << std::endl
        << "Book Author " << toPrint.author << std::endl
        << "Published by: " << toPrint.publisher << std::endl
        << "Date Added " << toPrint.dateAdded << std::endl
        << "ISBN: " << toPrint.ISBN << std::endl
        << "Quantity in hand:  " << toPrint.qtyInHand << std::endl
        << "Whole sale cost: $" << toPrint.wholesaleCost << std::endl
        << "Retail price: $" << toPrint.retailPrice << std::endl
        << std::endl;

    return out;
}

//Overload input stream Op
std::istream& operator>>(std::istream& in, Book& toCreate)
{
    //declared string variable to ignore the line space
    std::cout << std::endl;
    std::string temp;

    std::cout << std::endl;
    std::cout << "Using input overloading operator. . ." << std::endl;
    std::cout << "What is the title of the book? ";
    getline(in, toCreate.title);
    std::cout << "Who wrote this book? ";
    getline(in, toCreate.author);
    std::cout << "Who Published  this book? ";
    getline(in, toCreate.publisher);
    std::cout << "What was the date when this book was added (mm/dd/yyyy)? ";
    getline(in, toCreate.dateAdded);
    std::cout << "What the ISBN number for this book? ";
    getline(in, toCreate.ISBN);
    std::cout << "What is the quantity in hand? ";
    getline(in, toCreate.qtyInHand);
    std::cout << "What is the wholesale cost? ";
    getline(in, toCreate.wholesaleCost);
    std::cout << "What is the retail price? ";
    getline(in, toCreate.retailPrice);
    // used to ignore the line space in between book information
    getline(in, temp);
    std::cout << std::endl;

    return in;
}


Book::operator std::string()
{
    std::cout << std::endl;
    std::cout << "Returning ISBN. . ." << std::endl;
    return ISBN;
}





