/*
Lab 5: Operator Overloading in Classes
Author: Noah Khan
Description: Open bookdata.txt, using class overloading
             to extract book data and return data.
#######################################################

Pseudocode:
    Open book data file
    Create 10 book objects
    For loop to obtain 1st half of the books in bookdata.txt
    While loop to obtain the 2nd half of the of bookdata.txt
    For loop to output 1st half of book information (1)
    Another for loop to output 2nd half of book information (2)
    The second for loop uses the output overload
    Close Bookdata.txt
    Testing 3 new methods: copy, comparison, and return ISBN
    Creates new book object using overloaded copy operator
    Compares new book object and copied book object
    Compares new book object and different book object
    Casting new book object ISB
*/

#include "book.h"
#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main()
{
    ifstream infile;
    string   temp, readFile = "C:\\Users\\Khan\\Documents\\Coding Languages\\Intermediate C++\\Labs\\Lab 5\\Lab 5\\bookdata.txt";


    infile.open(readFile.c_str());
    if(infile)
    {
        cout << "Book data file successfully opened!" << endl;
        cout << endl;
    }

    Book library[10];
    cout << endl;

    // obtaining 1st half of book data
    cout << "Obtaining 1st half of book data (Overloaded input operator). . ." << endl;
    for (int i = 0; i<5; i++)
    {
        infile >> library[i];
    }

    // obtaining 2nd half of book data
    cout << endl;
    cout << "Obtaining 2nd half of book data (original). . ." << endl;
    int iteration = 5, counter = 1;
    while(infile)
    {
        getline(infile, temp);
        if (temp == "")
        {
            continue;
        }
        else if(counter == 1)
        {
            library[iteration].setTitle(temp);
            counter += 1;
        }
        else if(counter == 2)
        {
            library[iteration].setAuthor(temp);
            counter += 1;
        }
        else if(counter == 3)
        {
            library[iteration].setPublisher(temp);
            counter += 1;
        }
        else if(counter == 4)
        {
            library[iteration].setDateAdded(temp);
            counter += 1;
        }
        else if(counter == 5)
        {
            library[iteration].setISBN(temp);
            counter += 1;
        }
        else if(counter == 6)
        {
            library[iteration].setQty(temp);
            counter += 1;
        }
        else if(counter == 7)
        {
            library[iteration].setWholesale(temp);
            counter += 1;
        }
        else if(counter == 8)
        {
            library[iteration].setRetail(temp);
            counter = 1;
            iteration ++;
        }
    }

    cout << endl;
    cout << "Reading book information from loop (original method). . ." << endl;

    // Reading 1st half by original method (Lab 4)
    for (int i = 0; i < 5; i ++)
    {
        cout << "Book Number:  " << i+1 << endl;
        cout << "Title: '" << library[i].getTitle() << "'" << endl;
        cout << "Author: " << library[i].getAuthor() << endl;
        cout << "Publisher: " << library[i].getPublisher() << endl;
        cout << "Date Added: " << library[i].getDateAdded() << endl;
        cout << "ISBN: " << library[i].getISBN() << endl;
        cout << "Quantity: " << library[i].getQty() << endl;
        cout << "Whole Sale Price: $" << library[i].getWholesale() << endl;
        cout << "Retail Price: $" << library[i].getRetailPrice() << endl;
        cout << endl;
    }

    //Reading 2nd half using output stream over loader
    cout << "Reading book information using output stream operator (new method). . ." << endl;
    for (int j = 5; j<10; j++)
    {
        cout << "Book number: " << j+1;
        cout << library[j];
    }

    infile.close();
    cout << "Closing bookdata.txt. . ." << endl;
    cout << endl;

    //Testing 3 new written methods
    //1.) Copy method
    //2.) Using comparison operator
    //3.) Returns ISBN for book object

    // copy method
    cout << "Creating new book object using the copy method." << endl;
    Book newBook = library[9];

    // comparison operator
    if (newBook == library[9])
    {
        cout << "These book objects are equal to each other!" << endl;
    }

    cout << (newBook == library[0] ? "These book objects are equal to each other!" : "These book objects are equal not to each other!")
         << endl;

    // Getting ISBN for copied book object
    cout << "The ISBN for the newly copied book object is: " << static_cast<string>(newBook) << endl;

    cout << endl;
    system("pause");

    cout << endl;
    return 0;
}
