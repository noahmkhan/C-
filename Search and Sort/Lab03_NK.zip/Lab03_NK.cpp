/*
Lab 3: Sort and Search
Author: Noah Khan
Description: Contents of read file is transferred to a string array.
             Array is sorted get user input and find word and return
             index.
#######################################################

Pseudocode:
    SORT FUNCITON
    Take parameters  of a string array, int and string variable (already declared)
    compares the length of two elements and smallest length is placed to the left

    BINARY SEARCH FUNCTION
    Take parameters of a string array, integer variable, and string variable
    The last index values is divided by 2, this is where the search begins
    If the length of the middle element is less than user the length of the user input, remove the left half
    If the middle element is greater than the user input, remove right half
    Else if the element length is equal to user length, check if length are the same and strings are the same
    Check the element ahead and before in the case there is a repeated length
    If any other condition return -1 for string not found

    MAIN FUNCTION
    Initialize items
    Loop that asks for read file path
    If file did not open, display error and ask for path again
    If file opens display success message
    Ask for write file path
    Create counter for while loop
    Copy read file contents to temp variable
    If the temp variable length > 1, transfer data to array at index counter, where counter was initialized to 0
    Update counter and reset temp variable to " "
    Else continue the loop
    Call Sort function to sort array
    While expression is true do 1 of 3 cases
    Case 1. yesNoInput == Y, prompt user to enter word, store data into outfile, call BinarySearch, display index or not found
    Ask user if they would like to continue, records user input to outfile
    Case 2. yesNoInput == N, display quitting message and exit loop
    Case 3. yesNoInput does not equal Y or N, display error message and prompt the user to enter a proper character,
    and record user input to outfile
    Close read and write files
    Do system pause
*/

#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;



/**********************************************************/
/****************SELECTION SORT****************************/
void SelectionSort(string arr[], int numSize, string temp = " ")                                       // parameters = string array & int
{
    for (int i = 0; i < numSize - 1; i++)                                           // loop through array
    {
        int smallest = i;

        for(int j = i + 1; j < numSize; j++)
        {
            if (arr[j].length() < arr[smallest].length())                           // if j < small, j = smallest
            {
                smallest = j;
            }

        }

        temp = arr[i];                                                              // swap values, smallest to the left
        arr[i] = arr[smallest];
        arr[smallest] = temp;

    }
}
/****************SELECTION SORT****************************/
/**********************************************************/



/**********************************************************/
/****************BINARY SEARCH*****************************/
int BinarySearch(string arr[], int indexSize, string userInput) {
   int mid;                                                                                     // declare/initialize variables
   int low;
   int high;

   low = 0;
   high = indexSize - 1;

   while (high >= low) {                                                                       // while expression is true
      mid = (high + low) / 2;                                                                  // find middle element
      if (arr[mid].length() < userInput.length()) {                                            // compare middle length to user length
         low = mid + 1;                                                                        // if element < userinput, remove left side array
      }
      else if (arr[mid].length() > userInput.length()) {                                       // if userinput < element, remove right side array
         high = mid - 1;
      }
      else {                                                                                   // if user length == element length
            if((arr[mid] == userInput) && (arr[mid].length() == userInput.length()))           // compare length and staring
                {
                    return mid;
                }
            else if((arr[mid + 1] == userInput) && (arr[mid + 1].length() == userInput.length()))   //check on above
                {
                    return mid +1;
                }
            else if((arr[mid - 1] == userInput) && (arr[mid - 1].length() == userInput .length())) // check one below
                {
                    return mid - 1;
                }
            else{
                    return -1;                                                                      // else does not exist
            }
      }
   }
   return -1;                                                                                       // fail safe, not found
}
/****************BINARY SEARCH*****************************/
/*********************************************************/



int main()
{
    ifstream infile;                                                                // declare variables
    ofstream outfile;
    int num = 1024, counter = 0, output;
    string   readFile, writeFile, words[num], temp, userInput, yesNoInput = "Y";



    do{
        cout << "Enter read file path: " << endl;                                   // ask for path file
        getline(cin, readFile);

        infile.open(readFile.c_str());

        if(!infile)
        {
            cout << '\n' << "Error. . ." << endl;                                   // file not open == error msg
        }
        else if (infile)
        {
            cout << "Success!" << endl;                                             // open == good msg
        }

    }
    while(!infile);                                                                 // if not open, Do loop



    cout << '\n' << "Enter write file path: " << endl;                              // ask for write file path
    getline(cin, writeFile);

    outfile.open(writeFile.c_str());                                                // open write file



    counter = 0;                                                                    // copy read file to array
    while(infile)
    {
        infile >> temp;
        if(temp.length() > 1)                                                       // omit string length < 2
        {
            words[counter] = temp;
            counter ++;
            temp = " ";
        }
        else
        {
            continue;
        }

    }

    SelectionSort(words, num);                                                      // call sort function

    while( yesNoInput == yesNoInput )                                               // while loop
        {

        if(yesNoInput == "Y")                                                      // if expression = Y
            {                                                                      // ask user to enter word
            cout << '\n' << "Enter a word: " << endl;                              // store into var
            getline(cin, userInput);                                               // copy input to outfile
            outfile << userInput << endl;

            output = BinarySearch(words, num, userInput);                           // call function

            if(output < 0){
                cout << '\n' << "Not Found: " << output << endl;                    // if input not in array, return -1
            }
            else{
                cout << '\n' << "Index Found: " << output << endl;                  // if found return index
            }

        cout << "Would you like to search again? (enter Y or N)" << endl;           // search again?
        getline(cin, yesNoInput);                                                   // get input
        outfile << yesNoInput << endl;                                              // record user input
        }

        else if (yesNoInput == "N")                                                 // if input == N , quit
            {
            cout << '\n' << "Quiting. . ." << endl;
            break;
        }

        else
            {
            cout << '\n' << "Error. . ." << endl;                                    // if input != Y or N, display error
            cout << "Would you like to search again? (enter Y or N)" << endl;        // ask again
            getline(cin, yesNoInput);                                                // get input
            outfile << yesNoInput << endl;                                           // record data
        }

    }

    infile.close();                                                                  // close files and sys pause
    outfile.close();

    system("pause");

    return 0;
}


// C:\\Users\\Khan\\Documents\\Coding Languages\\Intermediate C++\\Labs\\Lab 3\\Lab03_NK\\test1.txt

