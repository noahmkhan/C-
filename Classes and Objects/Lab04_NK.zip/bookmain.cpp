/*
Lab 4: Classes and Objects
Author: Noah Khan
Description: Open book data file and copy contents to
             an array. Print out book information.
#######################################################

Pseudocode:
    Open book data file
    Create 10 book objects
    While loop to iterate through txt file
    Counter represents book attribute
    Sets data to book information
    For loop to iterate through array
    Prints out book information

*/

#include "book.h"
#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main()
{
    ifstream infile;
    string   temp, readFile = "C:\\Users\\Khan\\Documents\\Coding Languages\\Intermediate C++\\Labs\\Lab 4\\bookdata.txt";


    infile.open(readFile.c_str());
    if(infile)
    {
        cout << "Book data file successfully opened!" << endl;
        cout << endl;
    }

    Book library[10];
    int iteration = 0, counter = 1;
    cout << endl;

    while(infile)
    {
        getline(infile, temp);
        if (temp == "")
        {
            continue;
        }
        else if(counter == 1)
        {
            library[iteration].setTitle(temp);
            counter += 1;
        }
        else if(counter == 2)
        {
            library[iteration].setAuthor(temp);
            counter += 1;
        }
        else if(counter == 3)
        {
            library[iteration].setPublisher(temp);
            counter += 1;
        }
        else if(counter == 4)
        {
            library[iteration].setDateAdded(temp);
            counter += 1;
        }
        else if(counter == 5)
        {
            library[iteration].setISBN(temp);
            counter += 1;
        }
        else if(counter == 6)
        {
            library[iteration].setQty(temp);
            counter += 1;
        }
        else if(counter == 7)
        {
            library[iteration].setWholesale(temp);
            counter += 1;
        }
        else if(counter == 8)
        {
            library[iteration].setRetail(temp);
            counter = 1;
            iteration ++;
        }


    }

    cout << endl;

    for (int i = 0; i < 10; i ++)
    {
        cout << "Book Number:  " << i+1 << endl;
        cout << "Title: " << library[i].getTitle() << endl;
        cout << "Author: " << library[i].getAuthor() << endl;
        cout << "Publisher: " << library[i].getPublisher() << endl;
        cout << "Date Added: " << library[i].getDateAdded() << endl;
        cout << "ISBN: " << library[i].getISBN() << endl;
        cout << "Quantity: " << library[i].getQty() << endl;
        cout << "Whole Sale Price: $" << library[i].getWholesale() << endl;
        cout << "Retail Price: $" << library[i].getRetailPrice() << endl;
        cout << endl;
    }

    infile.close();

    cout << "Closing bookdata.txt. . ." << endl;
    cout << endl;

    system("pause");

    cout << endl;
    return 0;
}
