#include <string>
#ifndef BOOK_H
#define BOOK_H


class Book
{
public:
    void setTitle(std::string t) {title = t;}
    void setAuthor(std::string a){author = a;}
    void setPublisher(std::string p){publisher = p;}
    void setISBN(std::string isbn){ISBN = isbn;}
    void setDateAdded(std::string da){dateAdded = da;}
    void setQty(std::string qty){qtyInHand = qty;}
    void setWholesale(std::string ws){wholesaleCost = ws;}
    void setRetail(std::string rp) {retailPrice = rp;}

    std::string getTitle(){return title;}
    std::string getAuthor(){return author;}
    std::string getPublisher(){return publisher;}
    std::string getDateAdded(){return dateAdded;}

    std::string getISBN(){return ISBN;}
    std::string getQty(){return qtyInHand;}

    std::string getWholesale(){return wholesaleCost;}
    std::string getRetailPrice(){return retailPrice;}

    Book();             // Default constructor
    Book(const Book&);  // copy constructor
    Book(std::string t, std::string a, std::string p, std::string da, std::string isbn, std::string qty, std::string wc, std::string rp);
    ~Book();            // override default destructor

private:
    std::string title, author, publisher, dateAdded, ISBN, qtyInHand, wholesaleCost, retailPrice;
    //int qtyInHand;
    //double wholesaleCost, retailPrice;

};

#endif // BOOK_H




