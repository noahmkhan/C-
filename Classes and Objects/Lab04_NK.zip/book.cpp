#include "book.h"
#include <iostream>
#include <fstream>
#include <cstdlib>


Book::Book()        // Default Constructor
{
    std::cout << "Book object being created by default constructor. . ." << std::endl;

    title = "--";
    author = "--";
    publisher = "--";
    dateAdded = "0/0/00";
    ISBN = "0";
    qtyInHand = "0";
    wholesaleCost = "0";
    retailPrice = "0";

    std::cout << "Book " << getTitle() << " by " << author << std::endl;
}

Book::~Book()       // Destructor
{
    std::cout << "Book " << getTitle() << " by " << author <<
                  " destroyed successfully. . ." << std::endl;
}

Book::Book(std::string t, std::string a, std::string p, std::string da, std::string isbn, std::string qty, std::string wc, std::string rp) :
    title(t), author(a), publisher(p), dateAdded(da), ISBN(isbn), qtyInHand(qty), wholesaleCost(wc), retailPrice(rp)
{
    std::cout << "Book object being created by all parameter constructor. . ." << std::endl;

    std::cout << "Book " << getTitle() << " by " << author << std::endl;
}



